import Carousel from 'react-bootstrap/Carousel';

function MyCarousel(props) {
    return (
        <Carousel fade>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={props.src1}
                    alt="First slide"
                />
                <Carousel.Caption>
                    <h3>{props.text1}</h3>
                </Carousel.Caption>

            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={props.src2}
                    alt="Second slide"
                />

                <Carousel.Caption>
                    <h3>{props.text2}</h3>
                </Carousel.Caption>

            </Carousel.Item>
            <Carousel.Item>
                <img
                    className="d-block w-100"
                    src={props.src3}
                    alt="Third slide"
                />

                <Carousel.Caption>
                    <h3>{props.text3}</h3>
                </Carousel.Caption>

            </Carousel.Item>
        </Carousel>
    );
}

export default MyCarousel;
