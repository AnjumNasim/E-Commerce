import { Button, Col, Container, Row } from "react-bootstrap";
import './errorpage.css';
import { NavLink } from "react-router-dom";

function ErrorPage() {
    return (
        <>
            <Container>
                <Row>
                    <Col className="errorpage bg-">
                        <h2>404</h2>
                        <h3>Oops!!! Something went wrong</h3>
                        <p>The page you are looking for does not exist. But you can click the button below to go back to the home page. CIAO!</p>

                        <NavLink to='./'>
                            <Button variant="success">HOME</Button>
                        </NavLink>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default ErrorPage;