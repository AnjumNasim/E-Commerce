import { Container, Row, Col, Button } from 'react-bootstrap';
import Card from 'react-bootstrap/Card';
import './footer.css'



function Footer() {
    return (
        <>
            <Card className='footer-card'>
                <Container className='footer-container mt-3' >
                    <Row className='footer-row mb-5'>
                        <Col className='footer-about my-3'>
                            <h4>INFINITY MART</h4>
                            <p className='mt-3'>For anything that brings people together to celebrate an occasion, we create truly memorable experiences that you will cherish forever</p>
                        </Col>

                        <Col className='footer-subscribe my-3'>
                            <h4>SUBSCRIBE</h4>
                            <form action='#'>
                                <input className='footer-input mt-3' type='email' placeholder=' your email' />
                                <Button className='footer-btn mt-3' variant="success" value='subscribe'>SUBSCRIBE</Button>
                            </form>
                        </Col>

                        <Col className='footer-social my-3'>
                            <h4>FOLLOW US</h4>
                            <div className='footer-icons d-flex mt-3'>
                                <div >
                                    <a href='http://www.facebook.com'>
                                        <i className="fa-brands fa-facebook fa-3x"></i>
                                    </a>
                                </div>

                                <div>
                                    <a href="http://www.instagram.com">
                                        <i className="fa-brands fa-instagram  fa-3x" ></i>
                                    </a>
                                </div>

                                <div>
                                    <a href="http://www.snapchat.com">
                                        <i className="fa-brands fa-square-snapchat fa-3x"></i>
                                    </a>
                                </div>
                            </div>
                        </Col>

                        <Col className='footer-contact my-3'>
                            <h4>CONTACT US</h4>
                            <div className='footer-contact-div mt-3'>
                                <a href='tel:8697030362' >+91 8697030362</a><br/>
                                <a href='mail:infinitygroup@gmail.com'>infinitygroup@gmail.com</a>
                            </div>
                        </Col>
                    </Row>
                    <Card.Footer className="text-muted">
                        <p>©Infinity, All Right Reserved. Designed By React JS Codex</p>
                        <p>@{new Date().getFullYear()} Distributed By ThemeWagon</p>
                    </Card.Footer>
                </Container>
            </Card>
        </>
    )
}

export default Footer;