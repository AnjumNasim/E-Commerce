import { Container, Row, Col, Button } from "react-bootstrap"
import Image1 from '../Images/Cards Images/Room1.jpg'
import '../Rooms/rooms.css'


export default function Rooms() {
    return (
        <>
            <Container fluid>
                <Row>
                    <Col className="rooms-container">
                        <div >
                            <h2 className="rooms-herotext"><u>BLOGS</u></h2>
                        </div>
                    </Col>
                </Row>
            </Container>


            <Container>
                <Row className="blogs-row1">
                    <Col sm={9}>
                        <div className="blog-div my-5">
                            <img src={Image1} alt="blogs-images" style={{ height: '600px', width: '100%' }}></img>
                            <h2>Live your myth in Greece</h2>
                            <div className="blog-inner-div d-flex" style={{ display: 'flex', gap: '55px' }}>
                                <div style={{ display: 'flex', gap: '15px' }}>
                                    <i class="fa-solid fa-user"></i>
                                    <p>JOHN DOE</p>
                                </div>
                                <div style={{ display: 'flex', gap: '15px' }}>
                                    <i class="fa-solid fa-calendar-days"></i>
                                    <p>FEBRUARY 15, 2016</p>
                                </div>
                                <div style={{ display: 'flex', gap: '15px' }}>
                                    <i class="fa-solid fa-comment"></i>
                                    <p>75 COMMENTS</p>
                                </div>
                                <div style={{ display: 'flex', gap: '15px' }}>
                                    <i class="fa-regular fa-folder-open"></i>
                                    <p>NEWS, EVENTS</p>
                                </div>
                            </div>
                            <p className="blog-p">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit...</p>

                            <Button variant="outline-success" style={{ borderRadius: '0px' }}>Read More</Button>
                        </div>

                        <div>
                        </div>
                    </Col>
                    <Col sm={3}>
                        <div className="my-5" style={{ height: '600px', }}>

                            <h4 style={{ textAlign: 'center', backgroundColor:'aqua', height:'50px' }}>LATEST POSTS</h4>

                            <div className="mt-3" style={{ display: 'flex', height: '100px', gap:'10px'}}>
                                <img alt="" style={{ height: '100px', width: '50%', backgroundColor: 'grey' }} />
                                <div className="bg-light">
                                    <p>Live your myth in Greece</p>
                                    <div style={{display:'flex', gap:'10px'}}>
                                        <i class="fa-solid fa-calendar-days"></i>
                                        <p>25/04/2023</p>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-3" style={{ display: 'flex', height: '100px', gap:'10px' }}>
                                <img alt="" style={{ height: '100px', width: '50%', backgroundColor: 'grey' }} />
                                <div className="bg-light">
                                    <p>Live your myth in Greece</p>
                                    <div style={{display:'flex', gap:'10px'}}>
                                        <i class="fa-solid fa-calendar-days"></i>
                                        <p>25/04/2023</p>
                                    </div>
                                </div>
                            </div>

                            <div className="mt-3" style={{ display: 'flex', height: '100px', gap:'10px' }}>
                                <img alt="" style={{ height: '100px', width: '50%', backgroundColor: 'grey' }} />
                                <div className="bg-light">
                                    <p>Live your myth in Greece</p>
                                    <div style={{display:'flex', gap:'10px'}}>
                                        <i class="fa-solid fa-calendar-days"></i>
                                        <p>25/04/2023</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}