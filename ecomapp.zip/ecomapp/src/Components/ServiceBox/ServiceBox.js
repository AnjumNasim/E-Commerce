import { Col, Container, Row } from "react-bootstrap";
import { CiDeliveryTruck } from 'react-icons/ci';
import { RiSecurePaymentFill } from 'react-icons/ri'
import { GiReceiveMoney } from 'react-icons/gi'
import { AiOutlineSafety } from 'react-icons/ai'
import './servicebox.css';




function ServiceBox() {
    return (
        <>
            <Container>
                <Row className="ServiceRow" >
                    <Col sm style={{ padding: '2rem' }}>
                        <div className="ServBox1 bg-light">
                            <div>
                                <CiDeliveryTruck className="ServicerIcon mb-3" />
                                <h5>Superfast and Free delivery</h5>
                            </div>
                        </div>
                    </Col>

                    <Col sm style={{ padding: '2rem' }}>
                        <div className="ServBox2">
                            <Row style={{ gap: '4rem' }}>
                                <Col sm={12}>
                                    <div className="ServBox5 bg-light">
                                        <div>
                                            <AiOutlineSafety className="ServicerIcon2 mb-3"  />
                                            <h5>Non-Contact Shipping</h5>
                                        </div>
                                    </div>
                                </Col>

                                <Col sm={12} >
                                    <div className="ServBox5 bg-light">
                                        <div>     
                                            <GiReceiveMoney  className="ServicerIcon2 mb-3" />
                                            <h5>Money Back Gauranteed</h5>
                                        </div>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </Col>

                    <Col sm style={{ padding: '2rem' }}>
                        <div className=" ServBox3 bg-light">
                            <div>   
                                <RiSecurePaymentFill className="ServicerIcon mb-3" />
                                <h5>Super Secure Payment System</h5>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default ServiceBox;

