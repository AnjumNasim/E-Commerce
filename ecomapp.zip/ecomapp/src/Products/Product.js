import '../Products/product.css'
import { Col, Container, Row } from 'react-bootstrap'




function Products (){
    return (
        <>
            <Container>
                <Row>
                    <Col className='bg-light'>
                        <h1 className='my-5' style={{ backgroundColor:'wheat', border:'none', textAlign:'center', height:'500px'}}>PRODUCTS PAGE</h1>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
export default Products;


















































































// function Products() {

//     const [email, setMyEmail] = useState('');
//     const [password, setMyPassword] = useState('');
  
//     const [allEntry, setAllEntry] = useState([])

//     const SubmitForm = (e) => {
//         e.preventDefault();

//         if (email && password){
//             const newEntry = {id: new Date().getTime().toString(), email, password}

//             setAllEntry([...allEntry, newEntry]);
//             console.log(allEntry)
    
//             setMyEmail('');
//             setMyPassword('');
//         }else{
//             alert('Please fill all the fields')
//         }
//     }

//     return (
//         <>
//             <Container>
//                 <Row>
//                     <Col className='bg-light my-5'>
//                         <div className='bg-light mt-5'>
//                             <form action='' onSubmit={SubmitForm}>
                                
                                
//                                 <div>
//                                     <label htmlFor='email'> Email </label>
//                                     <input type='text' name='email' id='email' autoComplete='off'
//                                     value={email}
//                                     onChange={(e)=>setMyEmail(e.target.value)}
//                                     />
//                                 </div>

//                                 <div>
//                                     <label htmlFor='password'> Password </label>
//                                     <input type='password' name='password' id='password' autoComplete='off'
//                                     value={password}
//                                     onChange={(e)=>setMyPassword(e.target.value)}
//                                     />
//                                 </div>

//                                 <button type='submit' >Submit</button>
//                             </form>

//                             <div>
//                                 {
//                                     allEntry.map((cE) =>{
//                                         const {id, email, password} = cE
//                                         return (
//                                             <div key={id}>
//                                                 <p>{email}</p>
//                                                 <p>{password}</p>
//                                             </div>
//                                         )
//                                     })
//                                 }
//                             </div>

//                         </div>
//                     </Col>
//                 </Row>
//             </Container>
//         </>
//     )
// }

// export default Products;

















// To-Do List

// function ToDoList() {

//     const users = [
//         {
//             id: 0, userName: 'Anjum Nasim', userAge: 25, userLocation: 'Kolkata'
//         },
//         {
//             id: 1, userName: 'Rohan Chowdhury', userAge: 24, userLocation: 'Delhi'
//         },
//         {
//             id: 2, userName: 'Lakshya Arora', userAge: 23, userLocation: 'Chennai'
//         }
//     ]


//     const [myArray, setMyArray] = useState(users)

//     const ClearData = () => {
//         setMyArray([]);
//     }

//     const removeId = (i) => {
//         const newArray = myArray.filter((currElem) => {
//             return currElem.id !== i;
//         })

//         setMyArray(newArray);
//     }

//     return (
//         <>
//             <Container>
//                 <Row>
//                     <Col>
//                         {
//                             myArray.map((curEle) => {
//                                 return <h1 className="productH1" key={curEle.id}>Name: {curEle.userName} Age: {curEle.userAge}
//                                     Location: {curEle.userLocation}
//                                     <button onClick={() => removeId(curEle.id)}>Remove</button>
//                                 </h1>
//                             })
//                         }
//                         <button onClick={ClearData}>Clear</button>
//                     </Col>
//                 </Row>
//             </Container>
//         </>
//     )
// }

// export default ToDoList;