import { NavLink } from "react-router-dom";
import './header.css'
import MyNavbar from "./Navbar/Navbar";

function Header (){
    return (
        <>
            <div className="header" >
                <NavLink to='/'>
                    <img src="./Images/logo10.png" alt="logo" style={{height:'7rem'}}/>
                </NavLink>
                <MyNavbar />
            </div >
        </>
    )
}


export default Header;


// justify-content-space-between align-items-center position-relative