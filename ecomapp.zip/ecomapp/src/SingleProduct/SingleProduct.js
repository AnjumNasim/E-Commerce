import { Container, Row, Col, button } from "react-bootstrap";
import './singleproduct.css'
import { Divider } from "@mui/material";
import * as React from 'react';
import Typography from '@mui/material/Typography';
import { useParams } from "react-router-dom";

// Price Formatter
import FormatPrice from "../Components/FormatPrice/FormatPrice";

// React Icons 
import { CiDeliveryTruck } from 'react-icons/ci';
import { RiSecurePaymentFill } from 'react-icons/ri';
import { TbReplace } from 'react-icons/tb';
import { useEffect, useState } from "react";
// import { FaCheck } from 'react-icons/fa';


function SingleProduct() {
    const { id } = useParams();

    let arr = [{ url: '' }]
    const [myImage, setMyImage] = useState(arr)

    const [mainImage, setMainImage] = useState(arr)
    console.log(mainImage);

    // const [myColor, setMyColor] = useState([])
    // const [changeColor, setChangeColor] = useState(myColor[0])
    // console.log(changeColor)

    useEffect(() => {
        getSingleData();
    }, [])



    
    const [singleData, setSingleData] = useState([])
    const getSingleData = async () => {

        let res = await fetch(`https://api.pujakaitem.com/api/products/${id}`)
        let data = await res.json()
        setSingleData(data);
        setMyImage(data.image)
        // setMainImage(data.image)
        // setMyColor(data.colors)
    }

    const handleClick = () => {
        setMainImage(mainImage)
    }

    return (
        <>
            <Container>
                <Row>
                    <Col lg={8} >
                        <Row >
                            <Col >
                                <div className="sg-pr-div1 bg-light mb-4 mt-5" style={{ height: '400px', }}>
                                    <img src={mainImage[0].url} alt="" style={{ height: '400px', width: '100%' }} />
                                </div>
                            </Col>
                        </Row>

                        <Row >

                            {
                                myImage.map((e) => {
                                    return (
                                        <Col>
                                            <div className="bg-light" style={{ height: '170px' }}>
                                                <img src={e.url} alt="" style={{ height: '100%', width: '100%', cursor: 'pointer' }} onClick={handleClick} />
                                            </div>
                                        </Col>
                                    )
                                })
                            }

                        </Row>
                    </Col>

                    <Col lg={4}>


                        <div className="sg-pr-div2 bg-light my-5">
                            <div className="sg-pr-inner my-3">
                                <h3 style={{ fontFamily: 'sans-serif' }}>{singleData.name}</h3>
                                <Divider />

                                <div className='sg-pr-ratingbar mt-3 d-flex' style={{ gap: '20px' }}>
                                    <Typography component="legend">({singleData.reviews} customer reviews) </Typography>
                                </div>
                                <div className="mt-3">
                                    <del style={{ fontFamily: 'sans-serif', color: '#418cdb', fontWeight: '700' }}>
                                        MRP: {<FormatPrice price={singleData.price + 250000} />}
                                    </del>
                                </div>

                                <p style={{ fontFamily: 'sans-serif', color: '#418cdb', fontWeight: '700' }}>
                                    Deal of the day: {<FormatPrice price={singleData.price} />}
                                </p>

                                <p style={{ fontFamily: 'sans-serif', color: '#707477' }}>{singleData.description}</p>
                            </div>

                            <div className="d-flex my-4" style={{ justifyContent: 'space-evenly' }}>

                                <div className="sg-icons">
                                    <CiDeliveryTruck className="sg-truck" />
                                </div>

                                <div className="sg-icons">
                                    <RiSecurePaymentFill className="sg-payment" />
                                </div>

                                <div className="sg-icons">
                                    <TbReplace className="sg-replace" />
                                </div>
                            </div>

                            <Divider className="divider" />

                            <div className="my-3" style={{ fontFamily: 'sans-serif', color: '#707477' }}>
                                <p>AVAILABLE: {singleData.stock > 0 ? 'In Stock' : 'Out of Stock'}</p>
                                <p>ID: {singleData.id}</p>
                                <p>BRAND: {singleData.company}</p>
                                {/* <p className="d-flex">COLORS: {
                                    
                                    myColor.map((e, i)=>{
                                        return (
                                            <button className="sp-color-btn active" key={i} style={{backgroundColor: e}}>
                                                {changeColor === e ? <FaCheck/> : null}
                                            </button>
                                        )
                                    })

                                    }</p> */}
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
export default SingleProduct;










/* myImage[0].url   */