import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import { Button } from 'react-bootstrap';
import Divider from '@mui/material/Divider';
import '../Cards/cards.css';

// Currency Formatting
import FormatPrice from "../FormatPrice/FormatPrice";




export default function MUICard(props) {
  // const {id, name, image, price, category, description} = curEle;
  return (
    <Card sx={{ maxWidth: 350, borderRadius: '0px' }} className='card-main'>
      <CardActionArea>
        <CardMedia className='card-media'
          component="img"
          height="280"
          image={props.image}
          alt={props.name}
        />

        <Divider className='my-1' />
        <CardContent className='card-content'>
          <Typography gutterBottom variant="h6" component="div">
            {props.name}
          </Typography>
          <Typography variant="h6" color="text.secondary" className='my-2'>
            {<FormatPrice price={props.price} />}
          </Typography>
          <Divider className='mt-1 mb-2' />
          <Typography variant="body2" color="text.secondary">
            CATEGORY: {props.category}
          </Typography>
          <Divider className='my-2' />
          <Button variant='outline-success' size="small" style={{ borderRadius: "0px" }} ><b>SHOP</b></Button>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}