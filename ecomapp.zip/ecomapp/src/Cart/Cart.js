

function Cart (){
    return (
        <>
            <h1>Cart Page</h1>
        </>
    )
}

export default Cart;

