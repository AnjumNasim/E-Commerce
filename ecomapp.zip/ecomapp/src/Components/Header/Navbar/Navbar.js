import './navbar.css'
// import FiShoppingCart from 'react-icons';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css'
import {BsFillCartFill} from 'react-icons/bs'



function MyNavbar() {
    return (
        <>
            <Navbar expand="lg" className="bg-body-tertiary">
                <Container fluid>
                    <Navbar.Toggle aria-controls="navbarScroll" />
                    <Navbar.Collapse id="navbarScroll">
                        <Nav
                            className="me-auto my-2 my-lg-0"
                            style={{ maxHeight: '100px', fontWeight:600 }}
                            navbarScroll
                        >
                            <Nav.Link href="/">HOME</Nav.Link>
                            <Nav.Link href="/about">ABOUT</Nav.Link>
                            <Nav.Link href="/products">PRODUCTS</Nav.Link>
                            <Nav.Link href="/contact">CONTACT</Nav.Link>
                            <Nav.Link href="/rooms">ROOMS</Nav.Link>

                            <Nav.Link href="/cart" className='navbar-cart-link' style={{position:'relative'}}>
                                <BsFillCartFill className='navbar-cart-logo' />
                                <span className='navbar-cart-items'>7</span>
                            </Nav.Link>

                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </>
    )
}
export default MyNavbar;