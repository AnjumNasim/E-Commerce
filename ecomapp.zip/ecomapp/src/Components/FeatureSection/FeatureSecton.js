import './featuresection.css'
import { Container, Row, Col, Button } from "react-bootstrap";
import { NavLink } from "react-router-dom";
import { useEffect, useState } from "react";

// Currency Formatting
import FormatPrice from "../FormatPrice/FormatPrice";

// MUI Card
import * as React from 'react';
import { CardActionArea, Card, CardMedia, Typography, Divider, CardContent } from '@mui/material';
import '../Cards/cards.css';


function FeatureSection() {

    const [myData, setMyData] = useState([])
    const getData = async () => {
        const res = await fetch('https://api.pujakaitem.com/api/products')
        const data = await res.json();
        setMyData(data);
    }

    useEffect(() => {
        getData();
    }, [])


    return (
        <>
            <Container fluid>
                <Row>
                    <Col className="feature-col bg-light my-5">
                        <h4>Featured Products</h4>
                        <div className="feature-div d-flex">

                            {
                                myData.map((curEle) => {
                                    if (curEle.featured === true) {
                                        return (
                                            <>
                                                <NavLink key={curEle.id} to={`./singleproduct/${curEle.id}`} style={{ textDecoration: 'none' }}>
                                                    <Card sx={{ maxWidth: 350, borderRadius: '0px' }} className='card-main'>
                                                        <CardActionArea>
                                                            <CardMedia className='card-media'
                                                                component="img"
                                                                height="280"
                                                                image={curEle.image}
                                                                alt={curEle.name}
                                                            />

                                                            <Divider className='my-1' />
                                                            <CardContent className='card-content'>
                                                                <Typography gutterBottom variant="h6" component="div">
                                                                    {curEle.name}
                                                                </Typography>
                                                                <Typography variant="h6" color="text.secondary" className='my-2'>
                                                                    {<FormatPrice price={curEle.price} />}
                                                                </Typography>
                                                                <Divider className='mt-1 mb-2' />
                                                                <Typography variant="body2" color="text.secondary">
                                                                    CATEGORY: {curEle.category}
                                                                </Typography>
                                                                <Divider className='my-2' />
                                                                <Button variant='dark' size="small" style={{ borderRadius: "0px" }} ><b>SHOP</b></Button>
                                                            </CardContent>
                                                        </CardActionArea>
                                                    </Card>
                                                </NavLink>
                                            </>
                                        )
                                    }
                                })
                            }

                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default FeatureSection;











