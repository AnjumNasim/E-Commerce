import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import './owl.css';
import OwlCarousel from 'react-owl-carousel';
import { Container, Row } from 'react-bootstrap';
import Image from '../../Images/Cards Images/Room1.jpg'


function OwlDemo() {
    return (
        <>
            <Container fluid>
                <Row>
                    <OwlCarousel items={4}
                        className="owl-theme"
                        loop
                        nav
                        margin={8}>

                        <div className='owl-car-div'>
                            <img alt='images' className="owl-img" src={Image} />
                            <div className='owl-det bg-light'>
                                <h3 className='' style={{ fontWeight: 500 }}>GYM</h3>
                                <p className=''>5 Photos</p>
                            </div>
                        </div>

                        <div><img alt='images' className="owl-img" src={Image} /></div>
                        <div><img alt='images' className="owl-img" src={Image} /></div>
                        <div><img alt='images' className="owl-img" src={Image} /></div>
                        <div><img alt='images' className="owl-img" src={Image} /></div>
                        <div><img alt='images' className="owl-img" src={Image} /></div>
                        <div><img alt='images' className="owl-img" src={Image} /></div>
                    </OwlCarousel >
                </Row>
            </Container>
        </>
    )
}

export default OwlDemo;

