import { useEffect } from "react";


function FetchAPI (){

    const getData = () =>{
        let response = fetch('https://api.pujakaitem.com/api/products');
        let mydata = response.json();
    }

    useEffect(()=>{
        getData()
    })

}