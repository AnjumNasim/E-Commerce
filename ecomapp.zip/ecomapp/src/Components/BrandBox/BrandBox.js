import { Container, Row, Col } from "react-bootstrap";
import './brandbox.css';
import { SiNike, SiPuma, SiReebok, SiDell, SiLenovo } from 'react-icons/si'
import { CgAdidas } from 'react-icons/cg'
import { AiFillApple } from 'react-icons/ai'

function BrandBox() {
    return (
        <>
            <Container className="">
                <Row>
                    <Col>
                        <div className="BBdiv bg-light">
                            <Row>
                                <Col>
                                    <h5>Sponsored by Multi-national Companies</h5>
                                </Col>
                            </Row>
                            <Row>
                                <Col>
                                    <Row className="BBIcons mt-4">
                                        <Col sm>
                                            <SiNike className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <SiPuma className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <SiReebok className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <SiDell className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <SiLenovo className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <CgAdidas className="BrandIcons mt-4" />
                                        </Col>
                                        <Col sm>
                                            <AiFillApple className="BrandIcons mt-4" />
                                        </Col>
                                    </Row>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default BrandBox;

