import '../RoomBookings/roombookings.css'
import { Container, Row, Col } from 'react-bootstrap'
import Table from 'react-bootstrap/Table';



export default function RoomBookings() {
    return (
        <>
            <Container>
                <Row>
                    <Row>
                        <Col lg={9} className='bg-light my-5' style={{padding:'25px'}}>
                            <div className='d-flex my-5' style={{ justifyContent: 'space-between' }}>
                                <div>
                                    <h3>STANDARD ROOM</h3>
                                    <h6 className='color-blue'>$210.0 / NIGHT</h6>
                                </div>
                                <div className='rmb-icons'>
                                    <i class="fa-brands fa-facebook text-primary fa-3x"></i>
                                    <i class="fa-brands fa-twitter text-info fa-3x"></i>
                                    <i class="fa-brands fa-square-snapchat text-warning fa-3x"></i>
                                </div>
                            </div>
                            <div className='mb-5'>
                                <p>This large suite in the courtyard adobe has a Queen-size built-in platform bed and a large indoor/outdoor stone tub with a rain shower. The suite features a full kitchen with breakfast bar, a spacious sitting area with a wood burning fireplace. The private patio offers dramatic views of the San Jacinto Mountains. The suite features a full kitchen with breakfast bar, a spacious sitting area with a wood burning fireplace. The private patio offers dramatic views of the San Jacinto Mountains.

                                    The suite features a full kitchen with breakfast bar, a spacious sitting area with a wood burning fireplace. The private patio offers dramatic views of the San Jacinto Mountains.</p>
                            </div>

                            <div className='mb-5'>
                                <h5 className='color-blue'>AMENITIES & SERVICES</h5>
                                <div className='list-style'>
                                    <li><i class="fa fa-check color-blue icon-adjust"></i>Wi-Fi</li>
                                    <li><i class="fa fa-check color-blue icon-adjust"></i>Refrigeretor</li>
                                    <li><i class="fa fa-check color-blue icon-adjust"></i>Air-Condition</li>
                                </div>
                            </div>

                            <div className='mb-5'>
                                <h5 className='color-blue'>PRICING PLANS</h5>  
                                <div className='my-4'>
                                    <Table striped bordered hover size="lg" style={{textAlign:'center'}}>
                                        <tbody className='table-border'>
                                            <tr>
                                                <td>Mon</td>
                                                <td>Tue</td>
                                                <td>Wed</td>
                                                <td>Thu</td>
                                                <td>Fri</td>
                                                <td>Sat</td>
                                                <td>Sun</td>
                                            </tr>
                                            <tr>
                                                <td>$200</td>
                                                <td>$200</td>
                                                <td>$200</td>
                                                <td>$200</td>
                                                <td>$200</td>
                                                <td>$200</td>
                                                <td>$200</td>
                                            </tr>
                                        </tbody>
                                    </Table>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Row>
            </Container>
        </>
    )
}