import React, { Component } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import './owl.css';
import { Container, Row, Col, Button } from 'react-bootstrap';
import Image from '../../Images/CarouselImages/img1.jpg'

export default function MyOwlCarousel() {
    return (
        <>
            <Container fluid>
                <Row className='owl-row-title' sx={{ marginBottom: '20px' }}>
                    <Col sm>
                        <Button variant='info'>Owl Carousel In React Application</Button>
                    </Col>
                </Row>
                <Row>
                    <OwlCarousel items={3} margin={8} autoplay={true} >
                        <div ><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                        <div><img className="img" src={Image} /></div>
                    </OwlCarousel>
                </Row>
            </Container>
        </>
    )
}