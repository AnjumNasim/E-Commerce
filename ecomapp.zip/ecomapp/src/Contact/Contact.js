import { Container, Row, Col } from "react-bootstrap";
import GoogleMap from "../Components/GoogleMap/GoogleMap";
import './contact.css'
import MyForm from '../Components/Form/Form'

function Contact() {
    return (
        <>
            <Container fluid >
                <Row>
                    <Col className="contact mt-5">
                        <h2>CONTACT US</h2>
                        <GoogleMap />
                    </Col>
                </Row>
            </Container>

            <Container>
                <Row className="ContactRow">
                    <Col sm={5}>
                        <div className="ContactCol2 mb-5">
                                <MyForm />
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Contact;
