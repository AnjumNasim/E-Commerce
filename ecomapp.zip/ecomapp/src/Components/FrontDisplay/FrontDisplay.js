import { Container, Row, Col, Button } from "react-bootstrap";
import { NavLink } from "react-bootstrap";
import Image from '../../Images/FrontDisplayImages/FDImage1.jpg'
import './frontdisplay.css'


function FrontDisplay(props) {
    return (
        <>
            <Container className="FDCont bg-light">
                <Row >
                    <Col className="FDCol">
                        <div className="FrontDisplay-data">
                            <h6 className="intro" >WELCOME TO</h6>
                            <h1>{props.h1}</h1>
                            <p>{props.text1}</p>
                            <NavLink href="/products">
                                <Button variant="dark" style={{borderRadius:'0px', fontFamily:'sans-serif'}} className='FDbtn1'>SHOP</Button>
                            </NavLink>
                        </div>
                    </Col>
                    <Col className="">
                        <div className="FDimgdiv bg-dark">
                           <p>..</p>
                        </div>
                        <div className="FrontDisplay-image">
                            <figure>
                                <img
                                    src={Image}
                                    style={{ height: '25rem', width: '33rem' }}
                                    alt="Front Display Image"
                                    className="img-style"
                                />
                            </figure>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default FrontDisplay;