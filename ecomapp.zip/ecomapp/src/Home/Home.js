import { Container, Row, Col } from 'react-bootstrap';
import FrontDisplay from '../Components/FrontDisplay/FrontDisplay';
import ServiceBox from '../Components/ServiceBox/ServiceBox';
import BrandBox from '../Components/BrandBox/BrandBox';
import FeatureSection from '../Components/FeatureSection/FeatureSecton';


function Home() {
    return (
        <>
            <Container>
                <Row>
                    <Col className=''>
                        <div className='my-5'>
                            <FrontDisplay h1=' THE FAMILY MART ' text1='
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias
                                atque temporibus veniam doloribus libero ad error omnis voluptates
                                animi! Suscipit sapiente.'/>
                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col >
                        <div className='my-5'>
                            <FeatureSection/>
                        </div>
                    </Col>
                </Row>

                <Row>
                    <Col className=''>
                        <div className='homeServiceBox my-5'>
                            <ServiceBox />
                        </div>
                        <div className='homeBrandBox my-5'>
                            <BrandBox />
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
export default Home;