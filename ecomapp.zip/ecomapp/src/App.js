import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import Home from '../src/Home/Home';
import About from './About/About';
import Products from './Products/Product';
import Contact from './Contact/Contact';
import SingleProduct from '../src/SingleProduct/SingleProduct';
import Cart from './Cart/Cart';
import ErrorPage from './ErrorPage/ErrorPage';
import Header from './Components/Header/Header';
import Footer from './Components/Footer/Footer';
import Rooms from './Rooms/Rooms';


function App() {
  return (
    <>
    <BrowserRouter>
    <Header />
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/products' element={<Products/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/rooms' element={<Rooms/>}/>
        <Route path='/singleproduct/:id' element={<SingleProduct/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='*' element={<ErrorPage/>}/>
      </Routes>
      <Footer />
    </BrowserRouter>
    </>
  );
}

export default App;
