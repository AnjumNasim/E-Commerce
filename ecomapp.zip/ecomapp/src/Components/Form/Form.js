import { Container, Row, Col, Button } from "react-bootstrap"
import './form.css'


function MyForm() {

    return (
        <>
            <Container>
                <Row>
                    <Col className="my-5">
                        <div className="contact-div">

                            <form className="contact-form" action="https://formspree.io/f/mqkvzgjg" method="POST">

                                <input className="contact-form-input" 
                                    type="text"
                                    placeholder="   USERNAME"
                                    name="Username"
                                    required
                                    autoComplete="off"
                                    
                                /> <br/>

                                <input className="contact-form-input"
                                    type="email"
                                    name="Email"
                                    placeholder="   EMAIL"
                                    autoComplete="off"
                                    required
                                    
                                /><br/>

                                <textarea className="contact-form-TA"
                                    name="Message"
                                    cols="65"
                                    rows="10"
                                    required
                                    autoComplete="off"
                                    placeholder="   ENTER YOUR MESSAGE">
                                        
                                </textarea><br/>

                                <div>
                                    <Button variant="success"
                                    style={{borderRadius:'0px'}}
                                    className='Form-Button mb-4' type='' >SEND</Button>
                                </div>
                            </form>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default MyForm;