import { Container, Row, Col } from 'react-bootstrap';
import FrontDisplay from '../Components/FrontDisplay/FrontDisplay';



function About() {
    return (
        <>
            <Container>
                <Row>
                    <Col className=''>
                        <div className='my-5'>
                            <FrontDisplay h1=' THE FAMILY MALL ' text1='
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias
                                atque temporibus veniam doloribus libero ad error omnis voluptates
                                animi! Suscipit sapiente.'/>
                        </div>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default About;

